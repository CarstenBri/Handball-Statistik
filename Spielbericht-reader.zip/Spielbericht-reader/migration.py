import sqlite3
from datetime import datetime

# Name deiner Datenbankdatei
DB_NAME = 'spielberichte.db'

def migrate_date_format():
    """
    Konvertiert das Datumsformat in der 'spiele'-Tabelle von 'TT.MM.JJJJ' oder 'TT.MM.JJ' zu 'JJJJ-MM-TT'.
    Dieses Skript sollte nur einmal ausgeführt werden.
    """
    print(f"Verbinde mit der Datenbank '{DB_NAME}'...")
    try:
        conn = sqlite3.connect(DB_NAME, timeout=10)
        cursor = conn.cursor()

        cursor.execute("SELECT spielnummer, spieldatum FROM spiele")
        spiele = cursor.fetchall()

        if not spiele:
            print("Keine Spiele in der Datenbank gefunden. Nichts zu tun.")
            return

        print(f"{len(spiele)} Einträge gefunden. Starte die Konvertierung...")

        updated_count = 0
        for spielnummer, spieldatum_str in spiele:
            if not spieldatum_str or '-' in spieldatum_str:
                continue

            dt_object = None
            try:
                # Versuche zuerst das Format mit 4-stelligem Jahr
                dt_object = datetime.strptime(spieldatum_str, '%d.%m.%Y')
            except ValueError:
                try:
                    # Wenn das fehlschlägt, versuche das Format mit 2-stelligem Jahr
                    dt_object = datetime.strptime(spieldatum_str, '%d.%m.%y')
                except ValueError:
                    print(f"  - WARNUNG: Konnte das Datum für Spiel {spielnummer} nicht konvertieren ('{spieldatum_str}'). Überspringe.")
                    continue

            # Wenn eines der Formate erfolgreich war, update die DB
            if dt_object:
                new_date_str = dt_object.strftime('%Y-%m-%d')
                cursor.execute("UPDATE spiele SET spieldatum = ? WHERE spielnummer = ?", (new_date_str, spielnummer))
                print(f"  - Spiel {spielnummer}: '{spieldatum_str}' -> '{new_date_str}'")
                updated_count += 1

        conn.commit()

        if updated_count > 0:
            print(f"\nKonvertierung abgeschlossen. {updated_count} Einträge wurden erfolgreich aktualisiert.")
        else:
            print("\nKeine Einträge mussten aktualisiert werden. Das Datumsformat ist bereits korrekt.")

    except sqlite3.Error as e:
        print(f"Ein Datenbankfehler ist aufgetreten: {e}")
    finally:
        if conn:
            conn.close()
            print("Datenbankverbindung geschlossen.")

if __name__ == '__main__':
    migrate_date_format()